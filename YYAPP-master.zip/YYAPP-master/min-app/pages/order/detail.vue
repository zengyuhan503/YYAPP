<template>
    <view class="page-content">
     
    </view>
  </template>
  
  <script setup>
  import { ref, onMounted } from "vue";
  </script>
  
  <style lang="less" scoped>
  @import url("./index.less");
  </style>
  